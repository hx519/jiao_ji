import UserInfo from "../../Component/UserInfo/userInfo";
import { getUserByUserId } from "../../Services/UserService";
import { Button, Avatar } from "antd";


const AdminUserView = () => {
    return (
        <div>
            use
        </div>
    )
}

export default AdminUserView;